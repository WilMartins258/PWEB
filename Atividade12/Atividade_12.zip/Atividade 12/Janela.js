var janela = document.getElementById("janela");


function abrirJanela(){
	janela.src = "img/aberta.jpg";
}

function fecharJanela(){
	janela.src = "img/fechada.jpg";
}

function quebrarJanela(){
	janela.src = "img/quebrada.jpg";
}